package com.onlinecourse.platform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineCoursePlatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineCoursePlatformApplication.class, args);
	}

}
