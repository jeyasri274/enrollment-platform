package com.onlinecourse.platform.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {
    
    @GetMapping("/")
    public String home(Model model) {
        System.out.println("✅ Homepage loaded");
        return "index";
    }
    
    // Simple Signup - Just redirects to pages
    @PostMapping("/signup")
    public String signup(@RequestParam String name,
                        @RequestParam String email,
                        @RequestParam String password,
                        @RequestParam String phone,
                        @RequestParam String role,
                        Model model) {
        System.out.println("✅ SIGNUP FORM SUBMITTED:");
        System.out.println("Name: " + name);
        System.out.println("Email: " + email);
        System.out.println("Role: " + role);
        
        if ("student".equalsIgnoreCase(role)) {
            System.out.println("Redirecting to student page");
            model.addAttribute("userEmail", email);
            return "student";
        } else if ("instructor".equalsIgnoreCase(role)) {
            System.out.println("Redirecting to instructor page");
            model.addAttribute("userEmail", email);
            return "instructor";
        } else {
            System.out.println("Redirecting to admin page");
            return "admin";
        }
    }
    
    // Simple Login - Just redirects to dashboards
    @PostMapping("/login")
    public String login(@RequestParam String email,
                       @RequestParam String password,
                       @RequestParam String role) {
        System.out.println("✅ LOGIN FORM SUBMITTED:");
        System.out.println("Email: " + email);
        System.out.println("Role: " + role);
        
        if ("student".equalsIgnoreCase(role)) {
            System.out.println("Redirecting to student dashboard");
            return "student-dashboard";
        } else if ("instructor".equalsIgnoreCase(role)) {
            System.out.println("Redirecting to instructor dashboard");
            return "instructor-dashboard";
        } else {
            System.out.println("Redirecting to admin dashboard");
            return "admin";
        }
    }
    
    // Student form submission
    @PostMapping("/student/submit-details")
    public String submitStudentDetails(@RequestParam String fullName,
                                      @RequestParam String dateOfBirth,
                                      @RequestParam String studentId,
                                      @RequestParam String phone,
                                      @RequestParam String address,
                                      @RequestParam String education,
                                      @RequestParam String fieldOfStudy,
                                      @RequestParam String motivation,
                                      @RequestParam String userEmail,
                                      Model model) {
        System.out.println("✅ STUDENT DETAILS SUBMITTED:");
        System.out.println("Full Name: " + fullName);
        System.out.println("Student ID: " + studentId);
        System.out.println("User Email: " + userEmail);
        System.out.println("Redirecting to course enrollment");
        
        model.addAttribute("success", true);
        model.addAttribute("studentName", fullName);
        return "course-enrollment";
    }
    
    // Instructor form submission
    @PostMapping("/instructor/submit-details")
    public String submitInstructorDetails(@RequestParam String fullName,
                                         @RequestParam String instructorId,
                                         @RequestParam String email,
                                         @RequestParam String phone,
                                         @RequestParam String specialization,
                                         @RequestParam Integer experience,
                                         @RequestParam String qualification,
                                         @RequestParam String bio,
                                         @RequestParam String userEmail,
                                         Model model) {
        System.out.println("✅ INSTRUCTOR DETAILS SUBMITTED:");
        System.out.println("Full Name: " + fullName);
        System.out.println("Instructor ID: " + instructorId);
        System.out.println("User Email: " + userEmail);
        
        model.addAttribute("success", true);
        model.addAttribute("instructorName", fullName);
        return "instructor-dashboard";
    }
    
    // Direct page access
    @GetMapping("/student")
    public String studentPage() {
        System.out.println("✅ Student page accessed directly");
        return "student";
    }
    
    @GetMapping("/student-dashboard")
    public String studentDashboard() {
        System.out.println("✅ Student dashboard accessed");
        return "student-dashboard";
    }
    
    @GetMapping("/instructor")
    public String instructorPage() {
        System.out.println("✅ Instructor page accessed");
        return "instructor";
    }
    
    @GetMapping("/instructor-dashboard")
    public String instructorDashboard() {
        System.out.println("✅ Instructor dashboard accessed");
        return "instructor-dashboard";
    }
    
    @GetMapping("/admin")
    public String adminPage() {
        System.out.println("✅ Admin page accessed");
        return "admin";
    }
    
    @GetMapping("/course-enrollment")
    public String courseEnrollment() {
        System.out.println("✅ Course enrollment page accessed");
        return "course-enrollment";
    }
    
    // Other button endpoints
    @PostMapping("/student/enroll-course")
    public String enrollCourse(@RequestParam String courseName, Model model) {
        System.out.println("Enrolling in course: " + courseName);
        model.addAttribute("enrollmentSuccess", true);
        model.addAttribute("courseName", courseName);
        return "student-dashboard";
    }
    
    @GetMapping("/student/view-certificate")
    public String viewCertificate(@RequestParam String courseName, Model model) {
        System.out.println("Viewing certificate for: " + courseName);
        model.addAttribute("certificateCourse", courseName);
        return "student-dashboard";
    }
    
    @PostMapping("/instructor/add-course")
    public String addCourse(@RequestParam String courseTitle, Model model) {
        System.out.println("Adding new course: " + courseTitle);
        model.addAttribute("courseAdded", true);
        model.addAttribute("newCourse", courseTitle);
        return "instructor-dashboard";
    }
    
    @PostMapping("/admin/delete-user")
    public String deleteUser(@RequestParam String userId, Model model) {
        System.out.println("Deleting user: " + userId);
        model.addAttribute("userDeleted", true);
        model.addAttribute("deletedUser", userId);
        return "admin";
    }
}