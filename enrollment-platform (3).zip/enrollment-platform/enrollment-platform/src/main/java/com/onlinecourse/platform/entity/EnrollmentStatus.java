package com.onlinecourse.platform.entity;

public enum EnrollmentStatus {
    ACTIVE, COMPLETED, CANCELLED
}

