package com.onlinecourse.platform.entity;

public enum Role {
    STUDENT, INSTRUCTOR, ADMIN
}
