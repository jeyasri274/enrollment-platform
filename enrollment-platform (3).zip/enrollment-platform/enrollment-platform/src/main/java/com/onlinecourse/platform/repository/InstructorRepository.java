package com.onlinecourse.platform.repository;

import com.onlinecourse.platform.entity.Instructor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface InstructorRepository extends JpaRepository<Instructor, Long> {
    Optional<Instructor> findByInstructorId(String instructorId);
    Optional<Instructor> findByUserEmail(String userEmail);
    boolean existsByInstructorId(String instructorId);
    boolean existsByUserEmail(String userEmail);
}