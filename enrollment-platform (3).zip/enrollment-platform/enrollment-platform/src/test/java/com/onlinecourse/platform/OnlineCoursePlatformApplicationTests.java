package com.onlinecourse.platform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineCoursePlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
